class KioskSystem {
    constructor() {
        this.sellers = [{ username: 'Laey', password: '382004' }];
        this.products = {
            Pasta: [{ name: 'Spaghetti', price: 10 }, { name: 'Fettuccine', price: 12 }, { name: 'Penne', price: 8 }],
            Desserts: [{ name: 'Cake', price: 5 }, { name: 'Pie', price: 4 }, { name: 'Ice Cream', price: 3 }],
            Drinks: [{ name: 'Coke', price: 2 }, { name: 'Water', price: 1 }, { name: 'Juice', price: 3 }]
        };
        this.cart = [];
    }

    userAuthentication() {
        const username = prompt("Enter username:");
        const password = prompt("Enter password:");
        for (let user of this.sellers) {
            if (user.username === username && user.password === password) {
                return true;
            }
        }
        alert("Invalid credentials.");
        return false;
    }

    sellerOperations() {
        let action;
        do {
            action = prompt("Would you like to LOGOUT, ADD, or REMOVE an item?").toLowerCase();
            if (action === 'logout') break;
            else if (action === 'add') this.addItem();
            else if (action === 'remove') this.removeItem();
        } while (action !== 'logout');
    }

    addItem() {
        const category = prompt("Which category to update (Pasta, Desserts, Drinks)?").toLowerCase();
        if (!this.products[category]) {
            alert("Invalid category.");
            return;
        }
        const itemName = prompt("Enter the item name:");
        const itemPrice = parseFloat(prompt("Enter the price per item:"));
        this.products[category].push({ name: itemName, price: itemPrice });
        const continueAdding = prompt("Do you want to add another item? (yes/no)").toLowerCase();
        if (continueAdding === 'yes') this.addItem();
    }

    removeItem() {
        const category = prompt("Which category to update (Pasta, Desserts, Drinks)?").toLowerCase();
        if (!this.products[category]) {
            alert("Invalid category.");
            return;
        }
        const itemName = prompt("Enter the name of the item to remove:");
        const index = this.products[category].findIndex(item => item.name === itemName);
        if (index !== -1) {
            this.products[category].splice(index, 1);
            alert(`${itemName} has been removed from ${category}.`);
        } else {
            alert(`${itemName} not found in ${category}.`);
        }
        const continueRemoving = prompt("Do you want to remove another item? (yes/no)").toLowerCase();
        if (continueRemoving === 'yes') this.removeItem();
    }

    customerOperations() {
        let action;
        do {
            action = prompt("Would you like to ORDER, view CART, or CANCEL?").toLowerCase();
            if (action === 'order') this.placeOrder();
            else if (action === 'cart') this.viewCart();
            else if (action === 'cancel') break;
        } while (action !== 'cancel');
    }

    placeOrder() {
        const category = prompt("Choose a category (Pasta, Desserts, Drinks):").toLowerCase();
        if (!this.products[category]) {
            alert("Invalid category.");
            return;
        }

        let itemList = this.products[category].map((item, index) => `${index + 1}. ${item.name} - $${item.price}`).join('\n');
        const itemChoice = parseInt(prompt(`Available items:\n${itemList}\nChoose an item number:`)) - 1;
        if (itemChoice < 0 || itemChoice >= this.products[category].length) {
            alert("Invalid item choice.");
            return;
        }

        const quantity = parseInt(prompt("Enter quantity:"));
        const item = this.products[category][itemChoice];
        this.cart.push({ name: item.name, price: item.price, quantity: quantity });
        alert(`${item.name} has been added to your cart.`);

        const continueOrdering = prompt("Do you want to order another item? (yes/no)").toLowerCase();
        if (continueOrdering === 'yes') this.placeOrder();
    }

    viewCart() {
        if (this.cart.length === 0) {
            alert("Your cart is empty.");
            return;
        }

        let action;
        do {
            action = prompt("Would you like to PRINT the cart, ADD, REMOVE, or CANCEL?").toLowerCase();
            if (action === 'print') this.printCart();
            else if (action === 'add') this.placeOrder();
            else if (action === 'remove') this.removeFromCart();
            else if (action === 'cancel') break;
        } while (action !== 'cancel');
    }

    removeFromCart() {
        const itemName = prompt("Enter the name of the item to remove from cart:");
        const index = this.cart.findIndex(item => item.name === itemName);
        if (index !== -1) {
            this.cart.splice(index, 1);
            alert(`${itemName} has been removed from your cart.`);
        } else {
            alert(`${itemName} not found in your cart.`);
        }

        const continueRemoving = prompt("Do you want to remove another item? (yes/no)").toLowerCase();
        if (continueRemoving === 'yes') this.removeFromCart();
    }

    printCart() {
        let totalPrice = 0;
        let cartDetails = this.cart.map(item => {
            const total = item.price * item.quantity;
            totalPrice += total;
            return `${item.name} - $${item.price} x ${item.quantity} = $${total}`;
        }).join('\n');

        alert(`Your Cart:\n${cartDetails}\nTotal Price: $${totalPrice}`);
        this.cart = this.bubbleSortCart(this.cart);
    }

    bubbleSortCart(cart) {
        let sortedCart = [...cart];
        for (let i = 0; i < sortedCart.length; i++) {
            for (let j = 0; j < sortedCart.length - i - 1; j++) {
                if (sortedCart[j].name > sortedCart[j + 1].name) {
                    let temp = sortedCart[j];
                    sortedCart[j] = sortedCart[j + 1];
                    sortedCart[j + 1] = temp;
                }
            }
        }
        return sortedCart;
    }

    run() {
        let userType;
        do {
            userType = prompt("Are you a SELLER or CUSTOMER?").toLowerCase();
            if (userType === 'seller') {
                if (this.userAuthentication()) {
                    this.sellerOperations();
                }
            } else if (userType === 'customer') {
                this.customerOperations();
            } else {
                alert("Invalid input. Please try again.");
            }
        } while (userType !== 'exit');
    }
}

const kiosk = new KioskSystem();
kiosk.run();
